import SwiftUI

struct SignUpView: View {
    @Binding var users: [User]
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var phoneNumber: String = ""
    @State private var agreedToTerms: Bool = false
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack {
            TextField("이름", text: $name)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(5)
                .padding(.bottom, 20)

            TextField("아이디", text: $email)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(5)
                .padding(.bottom, 20)

            SecureField("패스워드", text: $password)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(5)
                .padding(.bottom, 20)

            TextField("전화번호", text: $phoneNumber)
                .keyboardType(.phonePad)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(5)
                .padding(.bottom, 20)

            Toggle(isOn: $agreedToTerms) {
                Text("약관에 동의합니다")
            }
            .padding(.bottom, 20)

            Button(action: {
                // 회원가입 로직
                if name.isEmpty || email.isEmpty || password.isEmpty || phoneNumber.isEmpty || !agreedToTerms {
                    alertMessage = "회원가입에 필요한 정보가 부족합니다."
                    showAlert = true
                } else if users.contains(where: { $0.email == email }) {
                    alertMessage = "이미 존재하는 이메일입니다."
                    showAlert = true
                } else {
                    let newUser = User(name: name, email: email, password: password)
                    users.append(newUser)
                    alertMessage = "회원가입 성공"
                    showAlert = true
                }
            }) {
                Text("회원가입")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(5)
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("알림"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("확인")) {
                        if alertMessage == "회원가입 성공" {
                            // 회원가입 성공 시 ContentView로 돌아가기
                            dismiss()
                        }
                    }
                )
            }
        }
        .padding()
        .navigationBarTitle("회원가입")
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView(users: .constant([]))
    }
}
