import SwiftUI

struct PostDetailView: View {
    var post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(post.title)
                .font(.headline)
            Text(post.content)
                .font(.subheadline)
            if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
            }
        }
        .padding()
        .navigationBarTitle("게시글 상세", displayMode: .inline)
    }
}

struct PostDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PostDetailView(post: Post(title: "Sample Title", content: "Sample Content", imageData: nil))
    }
}
