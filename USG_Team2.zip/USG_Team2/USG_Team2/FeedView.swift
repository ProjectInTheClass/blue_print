import SwiftUI

struct FeedView: View {
    @Binding var posts: [Post]

    var body: some View {
        ScrollView {
            VStack {
                ForEach(posts) { post in
                    VStack(alignment: .leading, spacing: 10) {
                        Text(post.title)
                            .font(.headline)
                        Text(post.content)
                            .font(.subheadline)
                        if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                        }
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    .padding(.top, 10)
                }
            }
        }
        .navigationBarTitle("피드")
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        FeedView(posts: .constant([]))
    }
}
