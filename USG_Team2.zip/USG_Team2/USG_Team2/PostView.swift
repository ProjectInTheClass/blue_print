import SwiftUI

struct PostView: View {
    @Binding var posts: [Post]
    @State private var title: String = ""
    @State private var content: String = ""
    @State private var image: UIImage?
    @State private var showImagePicker: Bool = false
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ScrollView {
            VStack {
                TextField("제목", text: $title)
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(5)
                    .padding(.bottom, 20)

                TextEditor(text: $content)
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(5)
                    .frame(height: 300)
                    .padding(.bottom, 20)

                if let image = image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .padding(.bottom, 20)
                }

                Button(action: {
                    showImagePicker = true
                }) {
                    Text("사진 추가")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(5)
                }
                .padding(.bottom, 20)
                .sheet(isPresented: $showImagePicker) {
                    ImagePicker(image: $image)
                }

                Button(action: {
                    let newPost = Post(title: title, content: content, imageData: image?.jpegData(compressionQuality: 0.8))
                    posts.append(newPost)
                    UserDefaults.standard.savePosts(posts)
                    title = ""
                    content = ""
                    image = nil
                    dismiss()  // 피드뷰로 이동
                }) {
                    Text("게시글 작성")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(5)
                }
            }
            .padding()
        }
        .navigationBarTitle("게시글 작성")
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(posts: .constant([]))
    }
}
