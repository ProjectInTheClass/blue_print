import SwiftUI

struct ContentView: View {
    @State private var users: [User] = UserDefaults.standard.loadUsers()
    @State private var posts: [Post] = UserDefaults.standard.loadPosts()
    @State private var isLoggedIn: Bool = false
    @State private var currentUser: User?

    var body: some View {
        if isLoggedIn, let currentUser = currentUser {
            MainTabView(posts: $posts, currentUser: currentUser)
                .onChange(of: posts) { newPosts in
                    UserDefaults.standard.savePosts(newPosts)
                }
        } else {
            NavigationStack {
                VStack {
                    NavigationLink("로그인", value: "LoginView")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(5)
                        .padding(.bottom, 20)

                    NavigationLink("회원가입", value: "SignUpView")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(5)
                }
                .navigationBarTitle("환영합니다")
                .navigationDestination(for: String.self) { value in
                    switch value {
                    case "LoginView":
                        LoginView(users: $users, isLoggedIn: $isLoggedIn, currentUser: $currentUser)
                    case "SignUpView":
                        SignUpView(users: $users)
                    default:
                        EmptyView()
                    }
                }
            }
            .onChange(of: users) { newUsers in
                UserDefaults.standard.saveUsers(newUsers)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
