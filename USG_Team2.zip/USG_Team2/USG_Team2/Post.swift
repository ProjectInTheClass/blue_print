import SwiftUI

struct Post: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var content: String
    var imageData: Data?

    static func == (lhs: Post, rhs: Post) -> Bool {
        return lhs.id == rhs.id && lhs.title == rhs.title && lhs.content == rhs.content && lhs.imageData == rhs.imageData
    }
}
