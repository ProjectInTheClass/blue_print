import Foundation

extension UserDefaults {
    private enum Keys {
        static let users = "users"
        static let posts = "posts"
    }

    func saveUsers(_ users: [User]) {
        if let encoded = try? JSONEncoder().encode(users) {
            set(encoded, forKey: Keys.users)
        }
    }

    func loadUsers() -> [User] {
        if let savedUsersData = data(forKey: Keys.users),
           let savedUsers = try? JSONDecoder().decode([User].self, from: savedUsersData) {
            return savedUsers
        }
        return []
    }

    func savePosts(_ posts: [Post]) {
        if let encoded = try? JSONEncoder().encode(posts) {
            set(encoded, forKey: Keys.posts)
        }
    }

    func loadPosts() -> [Post] {
        if let savedPostsData = data(forKey: Keys.posts),
           let savedPosts = try? JSONDecoder().decode([Post].self, from: savedPostsData) {
            return savedPosts
        }
        return []
    }
}
