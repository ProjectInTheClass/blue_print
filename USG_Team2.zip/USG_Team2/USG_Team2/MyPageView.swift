import SwiftUI

struct MyPageView: View {
    @Binding var posts: [Post]
    var currentUser: User

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .padding(.top, 20)

                    Text(currentUser.name)
                        .font(.title)
                        .padding(.top, 10)

                    LazyVGrid(columns: [GridItem(), GridItem(), GridItem()]) {
                        ForEach(posts) { post in
                            if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                                NavigationLink(destination: PostDetailView(post: post)) {
                                    Image(uiImage: uiImage)
                                        .resizable()
                                        .scaledToFit()
                                        .aspectRatio(1, contentMode: .fit)
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationBarTitle("마이페이지")
        }
    }
}

struct MyPageView_Previews: PreviewProvider {
    static var previews: some View {
        MyPageView(posts: .constant([]), currentUser: User(name: "Test User", email: "test@example.com", password: "password"))
    }
}
