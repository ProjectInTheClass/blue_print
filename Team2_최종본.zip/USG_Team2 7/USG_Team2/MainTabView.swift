import SwiftUI

struct MainTabView: View {
    @Binding var posts: [Post]
    var currentUser: User

    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("홈", systemImage: "house.fill")
                }

            FeedView(posts: $posts)
                .tabItem {
                    Label("피드", systemImage: "list.bullet")
                }

            PostView(posts: $posts)
                .tabItem {
                    Label("작성", systemImage: "square.and.pencil")
                }

            MyPageView(posts: $posts, currentUser: currentUser)
                .tabItem {
                    Label("마이페이지", systemImage: "person.crop.circle.fill")
                }
        }
    }
}

struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView(posts: .constant([]), currentUser: User(name: "Test User", email: "test@example.com", password: "password"))
    }
}
