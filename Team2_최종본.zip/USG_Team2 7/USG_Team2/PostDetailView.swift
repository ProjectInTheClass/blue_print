import SwiftUI

struct PostDetailView: View {
    var post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(post.title)
                .font(.headline)
            Text(post.content)
                .font(.subheadline)
            if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
            }

            HStack {
                Button(action: {
                    // 좋아요 토글 액션
                }) {
                    HStack {
                        Image(systemName: post.isLiked ? "hand.thumbsup.fill" : "hand.thumbsup")
                        Text("\(post.likes)")
                    }
                    .padding()
                    .background(post.isLiked ? Color.blue.opacity(0.2) : Color.blue.opacity(0.1))
                    .cornerRadius(5)
                    .foregroundColor(post.isLiked ? Color.blue : Color.primary)
                }

                Button(action: {
                    // 싫어요 토글 액션
                }) {
                    HStack {
                        Image(systemName: post.isDisliked ? "hand.thumbsdown.fill" : "hand.thumbsdown")
                        Text("\(post.dislikes)")
                    }
                    .padding()
                    .background(post.isDisliked ? Color.red.opacity(0.2) : Color.red.opacity(0.1))
                    .cornerRadius(5)
                    .foregroundColor(post.isDisliked ? Color.red : Color.primary)
                }
            }
        }
        .padding()
        .navigationBarTitle("게시글 상세", displayMode: .inline)
    }
}

struct PostDetailView_Previews: PreviewProvider {
    static var previews: some View {
        // 'author' 필드를 포함하여 Post 객체를 초기화
        PostDetailView(post: Post(
            id: UUID(),
            title: "Sample Title",
            content: "Sample Content",
            imageData: nil,
            likes: 0,
            dislikes: 0,
            isLiked: false,
            isDisliked: false,
            author: "Sample Author"  // 여기에 author 필드를 추가
        ))
    }
}
