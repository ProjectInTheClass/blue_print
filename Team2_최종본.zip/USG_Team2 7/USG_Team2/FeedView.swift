import SwiftUI

struct FeedView: View {
    @Binding var posts: [Post]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    // 게시글을 역순으로 보여주기 위해 reversed() 사용
                    ForEach(posts.indices.reversed(), id: \.self) { index in
                        NavigationLink(destination: PostDetailView(post: posts[index])) {
                            let post = posts[index]

                            GeometryReader { geometry in
                                VStack(alignment: .leading, spacing: 10) {
                                    // 사용자의 이름을 좌측 상단에 표시
                                    Text(post.author)
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .padding([.top, .leading], 10)

                                    // 게시글의 제목과 내용
                                    Text(post.title)
                                        .font(.headline)
                                        .padding([.leading, .trailing], 10)
                                    Text(post.content)
                                        .font(.subheadline)
                                        .padding([.leading, .trailing, .bottom], 10)

                                    // 이미지가 있는 경우 표시
                                    if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                                        Image(uiImage: uiImage)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: geometry.size.width * 0.4) // 이미지 크기를 화면 크기에 비례하게 설정
                                            .padding(.bottom, 10)
                                    }

                                    // 좋아요, 싫어요 버튼
                                    HStack {
                                        Button(action: {
                                            var updatedPost = posts[index]
                                            updatedPost.toggleLike()
                                            posts[index] = updatedPost
                                        }) {
                                            HStack {
                                                Image(systemName: post.isLiked ? "hand.thumbsup.fill" : "hand.thumbsup")
                                                Text("\(posts[index].likes)")
                                            }
                                            .padding()
                                            .background(post.isLiked ? Color.blue.opacity(0.2) : Color.blue.opacity(0.1))
                                            .cornerRadius(5)
                                            .foregroundColor(post.isLiked ? Color.blue : Color.primary)
                                        }

                                        Button(action: {
                                            var updatedPost = posts[index]
                                            updatedPost.toggleDislike()
                                            posts[index] = updatedPost
                                        }) {
                                            HStack {
                                                Image(systemName: post.isDisliked ? "hand.thumbsdown.fill" : "hand.thumbsdown")
                                                Text("\(posts[index].dislikes)")
                                            }
                                            .padding()
                                            .background(post.isDisliked ? Color.red.opacity(0.2) : Color.red.opacity(0.1))
                                            .cornerRadius(5)
                                            .foregroundColor(post.isDisliked ? Color.red : Color.primary)
                                        }
                                    }
                                    .padding([.leading, .trailing, .bottom], 10)
                                }
                                .frame(width: geometry.size.width - 40) // 양쪽에 20씩 패딩 적용
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(10)
                                .padding(.horizontal, 20)
                                .padding(.top, 5)
                            }
                            .frame(height: 400) // 카드의 전체 높이를 설정
                        }
                        .buttonStyle(PlainButtonStyle()) // 링크 버튼 스타일을 플레인으로 설정
                    }
                }
            }
            .navigationBarTitle("피드")
        }
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        FeedView(posts: .constant([
            Post(id: UUID(), title: "Sample Post", content: "This is a sample post content.", imageData: nil, likes: 0, dislikes: 0, isLiked: false, isDisliked: false, author: "Sample Author")
        ]))
    }
}
