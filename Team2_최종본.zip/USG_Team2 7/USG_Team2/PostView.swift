import SwiftUI

struct PostView: View {
    @Binding var posts: [Post]
    @State private var title: String = ""
    @State private var content: String = ""
    @State private var image: UIImage?
    @State private var showImagePicker: Bool = false
    @State private var showAlert: Bool = false
    @State private var isShowingFeedView: Bool = false
    @Environment(\.dismiss) var dismiss

    private var currentUserName: String {
        // UserDefaults 확장을 통해 현재 사용자의 이름을 가져옴
        return UserDefaults.standard.loadCurrentUser()?.name ?? "Laka"
    }

    var body: some View {
        VStack {
            ScrollView {
                VStack {
                    TextField("제목", text: $title)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(5)
                        .padding(.bottom, 20)

                    TextEditor(text: $content)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(5)
                        .frame(height: 300)
                        .padding(.bottom, 20)

                    if let image = image {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .padding(.bottom, 20)
                    }

                    Button(action: {
                        showImagePicker = true
                    }) {
                        Text("사진 추가")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(5)
                    }
                    .padding(.bottom, 20)
                    .sheet(isPresented: $showImagePicker) {
                        ImagePicker(image: $image)
                    }

                    Button(action: {
                        // Post 인스턴스 생성
                        let newPost = Post(
                            id: UUID(),
                            title: title,
                            content: content,
                            imageData: image?.jpegData(compressionQuality: 0.8),
                            likes: 0,
                            dislikes: 0,
                            isLiked: false,
                            isDisliked: false,
                            author: currentUserName  // 수정된 부분
                        )
                        posts.append(newPost)
                        UserDefaults.standard.savePosts(posts)
                        title = ""
                        content = ""
                        image = nil
                        showAlert = true  // 알림 표시
                    }) {
                        Text("게시글 작성")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(5)
                    }
                }
                .padding()
            }
            .navigationBarTitle("게시글 작성")
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("게시글 작성 완료"),
                    message: Text("게시글 작성이 완료되었습니다."),
                    dismissButton: .default(Text("완료")) {
                        isShowingFeedView = true
                    }
                )
            }
            .background(
                NavigationLink(
                    destination: FeedView(posts: $posts),
                    isActive: $isShowingFeedView
                ) {
                    EmptyView()
                }
            )
        }
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(posts: .constant([]))
    }
}
