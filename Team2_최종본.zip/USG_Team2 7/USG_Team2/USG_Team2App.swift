//
//  USG_Team2App.swift
//  USG_Team2
//
//  Created by usg on 8/9/24.
//

import SwiftUI

@main
struct USG_Team2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
