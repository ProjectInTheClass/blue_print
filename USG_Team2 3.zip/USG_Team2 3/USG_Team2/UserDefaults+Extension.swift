import Foundation

extension UserDefaults {
    private enum Keys {
        static let users = "users"
        static let posts = "posts"
    }

    // 사용자 저장
    func saveUsers(_ users: [User]) {
        let encoder = JSONEncoder()
        do {
            let encoded = try encoder.encode(users)
            set(encoded, forKey: Keys.users)
        } catch {
            print("Failed to encode users: \(error)")
        }
    }

    // 사용자 로드
    func loadUsers() -> [User] {
        guard let savedUsersData = data(forKey: Keys.users) else { return [] }
        let decoder = JSONDecoder()
        do {
            let savedUsers = try decoder.decode([User].self, from: savedUsersData)
            return savedUsers
        } catch {
            print("Failed to decode users: \(error)")
            return []
        }
    }

    // 게시글 저장
    func savePosts(_ posts: [Post]) {
        let encoder = JSONEncoder()
        do {
            let encoded = try encoder.encode(posts)
            set(encoded, forKey: Keys.posts)
        } catch {
            print("Failed to encode posts: \(error)")
        }
    }

    // 게시글 로드
    func loadPosts() -> [Post] {
        guard let savedPostsData = data(forKey: Keys.posts) else { return [] }
        let decoder = JSONDecoder()
        do {
            let savedPosts = try decoder.decode([Post].self, from: savedPostsData)
            return savedPosts
        } catch {
            print("Failed to decode posts: \(error)")
            return []
        }
    }
}
