import Foundation

struct User: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var email: String
    var password: String

    static func == (lhs: User, rhs: User) -> Bool {
        return lhs.id == rhs.id && lhs.name == rhs.name && lhs.email == rhs.email && lhs.password == rhs.password
    }
}
