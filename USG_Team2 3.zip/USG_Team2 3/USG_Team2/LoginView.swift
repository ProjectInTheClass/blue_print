import SwiftUI

struct LoginView: View {
    @Binding var users: [User]
    @Binding var isLoggedIn: Bool
    @Binding var currentUser: User?
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    var body: some View {
        VStack {
            TextField("아이디", text: $email)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(5)
                .padding(.bottom, 20)

            SecureField("패스워드", text: $password)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(5)
                .padding(.bottom, 20)

            Button(action: {
                // 로그인 로직
                if let user = users.first(where: { $0.email == email && $0.password == password }) {
                    currentUser = user
                    isLoggedIn = true
                } else {
                    alertMessage = "아이디 또는 패스워드가 잘못되었습니다."
                    showAlert = true
                }
            }) {
                Text("로그인")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(5)
            }
            .padding(.bottom, 20)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("로그인 실패"), message: Text(alertMessage), dismissButton: .default(Text("확인")))
            }

            NavigationLink(value: "SignUpView") {
                Text("회원가입")
                    .foregroundColor(.blue)
            }

            NavigationLink(destination: MainTabView(posts: .constant([]), currentUser: currentUser ?? User(name: "", email: "", password: "")), isActive: $isLoggedIn) {
                EmptyView()
            }
        }
        .padding()
        .navigationBarTitle("로그인")
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(users: .constant([]), isLoggedIn: .constant(false), currentUser: .constant(nil))
    }
}
