import Foundation

struct Post: Identifiable, Codable, Equatable {
    let id: UUID
    let title: String
    let content: String
    let imageData: Data?
    var likes: Int
    var dislikes: Int
    var isLiked: Bool
    var isDisliked: Bool

    // 좋아요 토글 메서드
    mutating func toggleLike() {
        if isLiked {
            likes -= 1
        } else {
            likes += 1
        }
        isLiked.toggle()
        if isDisliked {
            dislikes -= 1
            isDisliked.toggle()
        }
    }

    // 싫어요 토글 메서드
    mutating func toggleDislike() {
        if isDisliked {
            dislikes -= 1
        } else {
            dislikes += 1
        }
        isDisliked.toggle()
        if isLiked {
            likes -= 1
            isLiked.toggle()
        }
    }
}
