import SwiftUI

struct FeedView: View {
    @Binding var posts: [Post]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    ForEach(posts.indices, id: \.self) { index in
                        NavigationLink(destination: PostDetailView(post: posts[index])) {
                            let post = posts[index]
                            VStack(alignment: .leading, spacing: 10) {
                                Text(post.title)
                                    .font(.headline)
                                Text(post.content)
                                    .font(.subheadline)
                                if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                                    Image(uiImage: uiImage)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 200)
                                }

                                HStack {
                                    Button(action: {
                                        var updatedPost = posts[index]
                                        updatedPost.toggleLike()
                                        posts[index] = updatedPost
                                    }) {
                                        HStack {
                                            Image(systemName: post.isLiked ? "hand.thumbsup.fill" : "hand.thumbsup")
                                            Text("\(posts[index].likes)")
                                        }
                                        .padding()
                                        .background(post.isLiked ? Color.blue.opacity(0.2) : Color.blue.opacity(0.1))
                                        .cornerRadius(5)
                                        .foregroundColor(post.isLiked ? Color.blue : Color.primary)
                                    }

                                    Button(action: {
                                        var updatedPost = posts[index]
                                        updatedPost.toggleDislike()
                                        posts[index] = updatedPost
                                    }) {
                                        HStack {
                                            Image(systemName: post.isDisliked ? "hand.thumbsdown.fill" : "hand.thumbsdown")
                                            Text("\(posts[index].dislikes)")
                                        }
                                        .padding()
                                        .background(post.isDisliked ? Color.red.opacity(0.2) : Color.red.opacity(0.1))
                                        .cornerRadius(5)
                                        .foregroundColor(post.isDisliked ? Color.red : Color.primary)
                                    }
                                }
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(10)
                            .padding(.horizontal)
                            .padding(.top, 10)
                        }
                    }
                }
            }
            .navigationBarTitle("피드")
        }
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        FeedView(posts: .constant([
            Post(id: UUID(), title: "Sample Post", content: "This is a sample post content.", imageData: nil, likes: 0, dislikes: 0, isLiked: false, isDisliked: false)
        ]))
    }
}
