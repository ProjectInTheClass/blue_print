import SwiftUI

struct PostView: View {
    @Binding var posts: [Post]
    @State private var title: String = ""
    @State private var content: String = ""
    @State private var images: [UIImage] = []  // 사진을 여러 장 저장할 배열
    @State private var showImagePicker: Bool = false
    @State private var showAlert: Bool = false
    @State private var isShowingFeedView: Bool = false
    @Environment(\.dismiss) var dismiss

    private var currentUserName: String {
        UserDefaults.standard.loadCurrentUser()?.name ?? "Laka"
    }

    var body: some View {
        VStack {
            ScrollView {
                VStack {
                    TextField("제목", text: $title)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(5)
                        .padding(.bottom, 20)

                    TextEditor(text: $content)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(5)
                        .frame(height: 300)
                        .padding(.bottom, 20)

                    // 여러 장의 사진을 표시
                    ForEach(images, id: \.self) { image in
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .padding(.bottom, 20)
                    }

                    Button(action: {
                        showImagePicker = true
                    }) {
                        Text("사진 추가")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(5)
                    }
                    .padding(.bottom, 20)
                    .sheet(isPresented: $showImagePicker) {
                        ImagePicker(images: $images)
                    }

                    Button(action: {
                        let newPost = Post(
                            id: UUID(),
                            title: title,
                            content: content,
                            imageData: images.map { $0.jpegData(compressionQuality: 0.8) },  // 여러 장의 사진을 데이터로 변환
                            likes: 0,
                            dislikes: 0,
                            isLiked: false,
                            isDisliked: false,
                            author: currentUserName
                        )
                        posts.append(newPost)
                        UserDefaults.standard.savePosts(posts)
                        title = ""
                        content = ""
                        images.removeAll()  // 사진 배열 초기화
                        showAlert = true
                    }) {
                        Text("게시글 작성")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(5)
                    }
                }
                .padding()
            }
            .navigationBarTitle("게시글 작성")
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("게시글 작성 완료"),
                    message: Text("게시글 작성이 완료되었습니다."),
                    dismissButton: .default(Text("완료")) {
                        isShowingFeedView = true
                    }
                )
            }
            .background(
                NavigationLink(
                    destination: FeedView(posts: $posts),
                    isActive: $isShowingFeedView
                ) {
                    EmptyView()
                }
                .hidden()  // Hide the NavigationLink
            )
        }
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(posts: .constant([]))
    }
}
