//
//  SignUpViewController.swift
//  USG_Team2
//
//  Created by usg on 8/9/24.
//

import SwiftUI

struct SignUpViewController: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SignUpViewController()
}
