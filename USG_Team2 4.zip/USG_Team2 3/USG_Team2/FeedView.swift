import SwiftUI

struct FeedView: View {
    @Binding var posts: [Post]

    // 게시글을 최근 순으로 정렬하는 변수
    private var sortedPosts: [Post] {
        posts.sorted { $0.id > $1.id }
    }

    var body: some View {
        ScrollView {
            VStack {
                ForEach(sortedPosts) { post in
                    VStack(alignment: .leading, spacing: 10) {
                        Text(post.author)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        Text(post.title)
                            .font(.headline)
                        Text(post.content)
                            .font(.subheadline)
                        if let imageData = post.imageData, let uiImage = UIImage(data: imageData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                        }

                        HStack {
                            Button(action: {
                                var updatedPost = post
                                updatedPost.toggleLike()
                                if let index = posts.firstIndex(where: { $0.id == post.id }) {
                                    posts[index] = updatedPost
                                }
                            }) {
                                HStack {
                                    Image(systemName: post.isLiked ? "hand.thumbsup.fill" : "hand.thumbsup")
                                    Text("\(post.likes)")
                                }
                                .padding()
                                .background(post.isLiked ? Color.blue.opacity(0.2) : Color.blue.opacity(0.1))
                                .cornerRadius(5)
                                .foregroundColor(post.isLiked ? Color.blue : Color.primary)
                            }

                            Button(action: {
                                var updatedPost = post
                                updatedPost.toggleDislike()
                                if let index = posts.firstIndex(where: { $0.id == post.id }) {
                                    posts[index] = updatedPost
                                }
                            }) {
                                HStack {
                                    Image(systemName: post.isDisliked ? "hand.thumbsdown.fill" : "hand.thumbsdown")
                                    Text("\(post.dislikes)")
                                }
                                .padding()
                                .background(post.isDisliked ? Color.red.opacity(0.2) : Color.red.opacity(0.1))
                                .cornerRadius(5)
                                .foregroundColor(post.isDisliked ? Color.red : Color.primary)
                            }
                        }
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    .padding(.top, 10)
                }
            }
        }
        .navigationBarTitle("피드")
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        FeedView(posts: .constant([
            Post(id: UUID(), title: "Sample Post 1", content: "This is a sample post content.", imageData: nil, likes: 5, dislikes: 2, isLiked: true, isDisliked: false, author: "User 1"),
            Post(id: UUID(), title: "Sample Post 2", content: "This is another sample post content.", imageData: nil, likes: 3, dislikes: 1, isLiked: false, isDisliked: true, author: "User 2")
        ]))
    }
}
